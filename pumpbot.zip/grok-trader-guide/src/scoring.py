def score_token(checks, grok_result, config):
    failed = [
        name for name, item in checks.items()
        if item.get("status") != "PASS"
    ]

    risk = grok_result.get("risk", 10)

    approved = (
        len(failed) == 0
        and risk <= config["grok_max_risk"]
    )

    return {
        "approved": approved,
        "risk": risk,
        "failed_checks": failed,
        "reason": (
            "All checks passed"
            if approved else
            "Rejected: " + ", ".join(failed)
            if failed else
            f"Grok risk too high: {risk}"
        )
    }

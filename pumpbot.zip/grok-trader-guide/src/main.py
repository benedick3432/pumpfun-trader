import os
import sys
import json
import time
import argparse

from feed import scan, get_pair
from checks import check_token
from grok import analyze
from scoring import score_token
from paper import (
    load_state, save_state, buy, manage_positions,
    can_buy, log_event
)

def load_config():
    with open("config.json") as f:
        return json.load(f)

def run_demo(config):
    print("OFFLINE DEMO")
    fake = [
        {
            "symbol": "DEMO_SAFE",
            "address": "DEMO001",
            "price": 1.0,
            "liquidity": 50000
        },
        {
            "symbol": "DEMO_RISK",
            "address": "DEMO002",
            "price": 0.5,
            "liquidity": 1000,
            "lp_status": "UNKNOWN"
        },
        {
            "symbol": "DEMO_PASS",
            "address": "DEMO003",
            "price": 2.0,
            "liquidity": 50000,
            "lp_status": "PASS"
        }
    ]

    for token in fake:
        checks = {
            "liquidity": {
                "status": "PASS" if token["liquidity"] >= 25000 else "FAIL"
            },
            "lp_status": {"status": token.get("lp_status", "UNKNOWN")}
        }
        result = score_token(
            checks,
            {"risk": 3},
            config
        )
        print(
            token["symbol"],
            "APPROVED" if result["approved"] else "REJECTED",
            result["reason"]
        )
        log_event({
            "side": "DEMO",
            "symbol": token["symbol"],
            "reason": result["reason"]
        })

    print("DEMO TAMAMLANDI - Gerçek işlem yapılmadı.")

def run_once(config, state):
    tokens = scan(20)
    print("Bulunan token:", len(tokens))

    manage_positions(state, tokens, config)

    for token in tokens:
        print(
            "ANALYZING",
            token["symbol"],
            "Liquidity:",
            token["liquidity"],
            "Volume 5m:",
            token["volume5m"]
        )

        checks = check_token(token, config)

        if not checks["passed"]:
            log_event({
                "side": "SKIP",
                "symbol": token["symbol"],
                "address": token["address"],
                "checks": checks["checks"],
                "reason": "Security checks failed or unknown"
            })
            print("SKIP:", token["symbol"])
            continue

        ai = analyze(token, checks["checks"])
        decision = score_token(checks["checks"], ai, config)

        print(
            "GROK RISK:",
            ai["risk"],
            "DECISION:",
            decision["approved"]
        )

        if decision["approved"] and can_buy(state, config):
            buy(state, token, config)
        else:
            log_event({
                "side": "SKIP",
                "symbol": token["symbol"],
                "address": token["address"],
                "risk": ai["risk"],
                "reason": decision["reason"]
            })

    save_state(state)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    if os.getenv("MODE", "paper").lower() != "paper":
        print("LIVE MODE DISABLED. Only paper mode is supported.")
        sys.exit(1)

    config = load_config()

    if args.demo:
        run_demo(config)
        return

    state = load_state(config)
    interval = max(60, int(config["discovery_interval"]))

    print("GROK TRADER STARTED - PAPER MODE")
    print("Starting balance:", state["cash"])

    while True:
        try:
            run_once(config, state)
        except KeyboardInterrupt:
            print("Bot stopped.")
            break
        except Exception as e:
            print("MAIN ERROR:", repr(e))
            log_event({"side": "ERROR", "reason": repr(e)})

        if args.once:
            break

        time.sleep(interval)

if __name__ == "__main__":
    main()

import os
import json
import time
from datetime import datetime, timezone

DATA = "data/paper_state.json"
LOG = "logs/decisions.jsonl"

FEE_RATE = 0.01
SLIPPAGE_RATE = 0.02

def now():
    return datetime.now(timezone.utc).isoformat()

def load_state(config):
    os.makedirs("data", exist_ok=True)
    if os.path.exists(DATA):
        with open(DATA) as f:
            return json.load(f)

    state = {
        "cash": float(config["initial_balance"]),
        "initial_balance": float(config["initial_balance"]),
        "positions": {},
        "realized_pnl": 0,
        "daily_pnl": 0,
        "day": datetime.now().date().isoformat(),
        "trades": 0
    }
    save_state(state)
    return state

def save_state(state):
    with open(DATA, "w") as f:
        json.dump(state, f, indent=2)

def log_event(event):
    os.makedirs("logs", exist_ok=True)
    event["timestamp"] = now()
    with open(LOG, "a") as f:
        f.write(json.dumps(event) + "\n")

def reset_day(state):
    today = datetime.now().date().isoformat()
    if state.get("day") != today:
        state["day"] = today
        state["daily_pnl"] = 0

def buy(state, token, config):
    address = token["address"]

    if address in state["positions"]:
        return False

    price = float(token.get("price", 0))
    if price <= 0 or state["cash"] <= 0:
        return False

    size = min(
        state["cash"],
        state["initial_balance"] * config["max_position_pct"]
    )

    cost = size * (1 + FEE_RATE)
    if cost > state["cash"]:
        return False

    effective_price = price * (1 + SLIPPAGE_RATE)
    quantity = size / effective_price

    state["cash"] -= cost
    state["positions"][address] = {
        "symbol": token.get("symbol", "UNKNOWN"),
        "quantity": quantity,
        "entry_price": effective_price,
        "entry_cost": cost,
        "last_price": price
    }

    state["trades"] += 1
    save_state(state)

    log_event({
        "side": "BUY",
        "symbol": token.get("symbol"),
        "address": address,
        "price": price,
        "cost": cost,
        "mode": "PAPER"
    })
    return True

def sell(state, address, price, reason):
    position = state["positions"].get(address)
    if not position or price <= 0:
        return False

    effective_price = price * (1 - SLIPPAGE_RATE)
    proceeds = (
        position["quantity"] * effective_price * (1 - FEE_RATE)
    )

    pnl = proceeds - position["entry_cost"]
    state["cash"] += proceeds
    state["realized_pnl"] += pnl
    state["daily_pnl"] += pnl
    state["trades"] += 1

    log_event({
        "side": "SELL",
        "symbol": position["symbol"],
        "address": address,
        "price": price,
        "pnl": round(pnl, 4),
        "reason": reason,
        "mode": "PAPER"
    })

    del state["positions"][address]
    save_state(state)
    return True

def manage_positions(state, tokens, config):
    prices = {
        t["address"]: t["price"]
        for t in tokens if t.get("price", 0) > 0
    }

    for address in list(state["positions"]):
        if address not in prices:
            continue

        position = state["positions"][address]
        price = prices[address]
        position["last_price"] = price

        entry = position["entry_price"]
        change = price / entry - 1

        if change <= -config["stop_loss_pct"]:
            sell(state, address, price, "STOP_LOSS")

    save_state(state)

def can_buy(state, config):
    reset_day(state)

    max_loss = (
        state["initial_balance"] *
        config["max_daily_loss_pct"]
    )

    if state["daily_pnl"] <= -max_loss:
        return False

    return True

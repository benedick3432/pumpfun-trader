import os
import time
import requests
from dotenv import load_dotenv

load_dotenv()

RPC = os.getenv(
    "SOLANA_RPC_URL",
    "https://api.mainnet.solana.com"
)

SESSION = requests.Session()


def rpc(method, params):
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params
    }

    try:
        response = SESSION.post(
            RPC, json=payload, timeout=20
        )
        response.raise_for_status()
        data = response.json()

        if "error" in data:
            return None

        return data.get("result")

    except Exception as e:
        print("SOLANA RPC ERROR:", e)
        return None


def check_token(token, config):
    address = token["address"]

    result = {
        "address": address,
        "checks": {},
        "passed": False
    }

    def record(name, status, detail):
        result["checks"][name] = {
            "status": status,
            "detail": detail
        }

    # Liquidity
    liquidity = token.get("liquidity")
    min_liquidity = config["min_liquidity_usd"]

    if liquidity is None:
        record("liquidity", "UNKNOWN", "Liquidity unavailable")
    else:
        try:
            liquidity = float(liquidity)
            record(
                "liquidity",
                "PASS" if liquidity >= min_liquidity else "FAIL",
                f"${liquidity:.2f}"
            )
        except (TypeError, ValueError):
            record("liquidity", "UNKNOWN", "Invalid liquidity data")

    # Pool age
    created = token.get("createdAt")
    if created:
        age = max(0, (time.time() * 1000 - created) / 60000)
        age_ok = age >= config["min_pool_age_minutes"]
        record("pool_age", "PASS" if age_ok else "FAIL",
               f"{age:.1f} minutes")
    else:
        record("pool_age", "UNKNOWN", "Pool age unavailable")

    # Token supply
    supply_data = rpc("getTokenSupply", [address])

    # Largest token accounts
    holders_data = rpc(
        "getTokenLargestAccounts",
        [address]
    )

    # Mint account
    mint_data = rpc(
        "getAccountInfo",
        [
            address,
            {"encoding": "jsonParsed"}
        ]
    )

    if not supply_data or not holders_data or not mint_data:
        record("holder_distribution", "UNKNOWN", "RPC data unavailable")
        record("mint_authority", "UNKNOWN", "RPC data unavailable")
        record("freeze_authority", "UNKNOWN", "RPC data unavailable")
        record("lp_status", "UNKNOWN", "No verified LP provider")
        return result

    try:
        supply = float(
            supply_data["value"]["amount"]
        )

        accounts = holders_data["value"]

        if supply <= 0 or not accounts:
            raise ValueError("Invalid supply or holder data")

        amounts = [
            float(x["amount"]) for x in accounts
        ]

        largest_share = amounts[0] / supply
        top10_share = sum(amounts[:10]) / supply

        single_ok = (
            largest_share <= config["max_single_holder"]
        )
        top10_ok = (
            top10_share <= config["max_top10_share"]
        )

        record(
            "holder_distribution",
            "PASS" if single_ok and top10_ok else "FAIL",
            f"Largest token account: {largest_share:.2%}; "
            f"Top 10 token accounts: {top10_share:.2%}"
        )

        parsed = (
            mint_data["value"]["data"]["parsed"]["info"]
        )

        mint_authority = parsed.get("mintAuthority")
        freeze_authority = parsed.get("freezeAuthority")

        mint_ok = (
            mint_authority is None
            if config["require_mint_disabled"]
            else True
        )

        freeze_ok = (
            freeze_authority is None
            if config["require_freeze_disabled"]
            else True
        )

        record(
            "mint_authority",
            "PASS" if mint_ok else "FAIL",
            str(mint_authority)
        )

        record(
            "freeze_authority",
            "PASS" if freeze_ok else "FAIL",
            str(freeze_authority)
        )

    except (KeyError, TypeError, ValueError, IndexError) as e:
        record("holder_distribution", "UNKNOWN", str(e))
        record("mint_authority", "UNKNOWN", "Invalid mint data")
        record("freeze_authority", "UNKNOWN", "Invalid mint data")

    # LP lock cannot be verified without a provider.
    record(
        "lp_status",
        "UNKNOWN",
        "No verified LP lock provider configured"
    )

    result["passed"] = all(
        item["status"] == "PASS"
        for item in result["checks"].values()
    )

    return result

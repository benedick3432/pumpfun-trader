import json
from http.server import HTTPServer, BaseHTTPRequestHandler

STATE = "data/paper_state.json"
LOG = "logs/decisions.jsonl"

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            with open(STATE) as f:
                state = json.load(f)
        except Exception:
            state = {}

        try:
            with open(LOG) as f:
                events = [
                    json.loads(x) for x in f.readlines()[-50:]
                ]
        except Exception:
            events = []

        positions = state.get("positions", {})

        rows = "".join(
            "<tr><td>{}</td><td>{:.8f}</td><td>{:.6f}</td></tr>".format(
                p.get("symbol", ""),
                p.get("entry_price", 0),
                p.get("quantity", 0)
            )
            for p in positions.values()
        )

        history = "".join(
            "<tr><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                e.get("timestamp", "")[:19],
                e.get("side", ""),
                e.get("symbol", "")
            )
            for e in reversed(events)
        )

        page = """
        <!DOCTYPE html>
        <html>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="15">
        <title>Grok Trader</title>
        <style>
        body{background:#111;color:#eee;font-family:Arial;padding:15px}
        .box{background:#222;padding:15px;margin:10px 0;border-radius:10px}
        table{width:100%;font-size:12px;text-align:left}
        td,th{padding:7px;border-bottom:1px solid #444}
        h1{color:#ef4444}
        </style>
        <h1>GROK TRADER</h1>
        <div class="box">
        <h3>PAPER PORTFOLIO</h3>
        <p>Cash: $CASH</p>
        <p>Realized PnL: $PNL</p>
        <p>Daily PnL: $DAILY</p>
        <p>Open positions: $COUNT</p>
        <p>Total trades: $TRADES</p>
        </div>
        <div class="box">
        <h3>OPEN POSITIONS</h3>
        <table><tr><th>Token</th><th>Entry</th><th>Quantity</th></tr>
        $ROWS</table>
        </div>
        <div class="box">
        <h3>RECENT TRADES</h3>
        <table><tr><th>Time</th><th>Side</th><th>Token</th></tr>
        $HISTORY</table>
        </div>
        </html>
        """

        replacements = {
            "$CASH": "{:.2f}".format(state.get("cash", 0)),
            "$PNL": "{:.2f}".format(state.get("realized_pnl", 0)),
            "$DAILY": "{:.2f}".format(state.get("daily_pnl", 0)),
            "$COUNT": str(len(positions)),
            "$TRADES": str(state.get("trades", 0)),
            "$ROWS": rows,
            "$HISTORY": history
        }

        for key, value in replacements.items():
            page = page.replace(key, value)

        body = page.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass

if __name__ == "__main__":
    print("Dashboard: http://127.0.0.1:8000")
    HTTPServer(("0.0.0.0", 8000), Handler).serve_forever()

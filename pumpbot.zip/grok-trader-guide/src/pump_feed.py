import os
import sys
import json
import time
from pathlib import Path
from datetime import datetime, timezone

import websocket
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

API_KEY = os.getenv("PUMPPORTAL_API_KEY", "").strip()
URL = "wss://pumpportal.fun/api/data"
if API_KEY:
    URL += "?api-key=" + API_KEY

OUTPUT = ROOT / "data" / "pump_new_tokens.jsonl"

def run(seconds=120):
    print("PUMP.FUN CANLI TOKEN TARAMASI")
    print("Süre:", seconds, "saniye")
    print("Ücretli trade kanalı: KAPALI")
    print("Bağlantı kuruluyor...")

    ws = websocket.create_connection(URL, timeout=10)
    ws.send(json.dumps({"method": "subscribeNewToken"}))
    print("ABONE OLUNDU: subscribeNewToken")

    start = time.time()
    seen = set()
    count = 0

    try:
        while time.time() - start < seconds:
            try:
                raw = ws.recv()
            except websocket.WebSocketTimeoutException:
                continue

            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if isinstance(data, list):
                events = data
            else:
                events = [data]

            for token in events:
                if not isinstance(token, dict):
                    continue

                mint = token.get("mint") or token.get("tokenAddress")
                if not mint or mint in seen:
                    continue

                seen.add(mint)
                count += 1

                record = {
                    "received_at": datetime.now(timezone.utc).isoformat(),
                    "source": "pumpportal",
                    "mint": mint,
                    "name": token.get("name", ""),
                    "symbol": token.get("symbol", ""),
                    "creator": token.get("traderPublicKey", ""),
                    "market_cap_sol": token.get(" marketCapSol", token.get("marketCapSol")),
                    "uri": token.get("uri", ""),
                    "raw": token
                }

                with OUTPUT.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")

                print(
                    f"[YENİ TOKEN {count}] "
                    f"{record['name']} ({record['symbol']})"
                )
                print("MINT:", mint)

    finally:
        ws.close()

    print("\nTARAMA BİTTİ")
    print("Yakalanan token:", count)
    print("Kayıt:", OUTPUT)

if __name__ == "__main__":
    try:
        duration = int(sys.argv[1]) if len(sys.argv) > 1 else 120
        run(max(10, min(duration, 3600)))
    except KeyboardInterrupt:
        print("\nTarama kullanıcı tarafından durduruldu.")
    except Exception as e:
        print("TARAMA HATASI:", repr(e))
        sys.exit(1)

import time
import requests

BASE = 'https://api.dexscreener.com'

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "GrokTrader/1.0"})


def get_json(url):
    try:
        r = SESSION.get(url, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("DEXSCREENER API ERROR:", e)
        return None


def discover_tokens(limit=10):
    data = get_json(BASE + "/token-profiles/latest/v1")

    if not isinstance(data, list):
        return []

    tokens = []
    seen = set()

    for item in data:
        if item.get("chainId") != "solana":
            continue

        address = item.get("tokenAddress")

        if not address or address in seen:
            continue

        seen.add(address)

        tokens.append({
            "address": address,
            "name": item.get("name", "Unknown"),
            "symbol": item.get("symbol", "UNKNOWN")
        })

        if len(tokens) >= limit:
            break

    return tokens


def get_pair(address):
    data = get_json(
        f"{BASE}/token-pairs/v1/solana/{address}"
    )

    if not isinstance(data, list) or not data:
        return None

    pairs = [
        p for p in data
        if isinstance(p, dict)
    ]

    if not pairs:
        return None

    def liquidity_value(pair):
        value = (pair.get("liquidity") or {}).get("usd")
        try:
            return float(value) if value is not None else -1
        except (TypeError, ValueError):
            return -1

    return max(pairs, key=liquidity_value)


def scan(limit=10):
    results = []

    for token in discover_tokens(limit):
        time.sleep(1.1)

        pair = get_pair(token["address"])

        if not pair:
            continue

        token["pair"] = pair

        liquidity = (pair.get("liquidity") or {}).get("usd")
        try:
            token["liquidity"] = (
                float(liquidity) if liquidity is not None else None
            )
        except (TypeError, ValueError):
            token["liquidity"] = None

        try:
            token["price"] = float(pair.get("priceUsd") or 0)
        except (TypeError, ValueError):
            token["price"] = 0

        token["volume5m"] = (
            pair.get("volume", {}).get("m5")
        )

        token["createdAt"] = pair.get("pairCreatedAt")

        results.append(token)

    return results

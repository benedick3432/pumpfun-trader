import os, json, time, requests
from pathlib import Path
from datetime import datetime, timezone
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

GROQ_KEY = os.getenv("GROQ_API_KEY", "").strip()
DEX = "https://api.dexscreener.com/tokens/v1/solana/"

MIN_LIQ = 25000
MIN_VOL5 = 5000
MIN_TX5 = 20

def grok_review(token):
    if not GROQ_KEY:
        return {"risk": 10, "decision": "REJECT", "reason": "Groq API anahtarı yok"}

    prompt = {
        "task": "Evaluate this Solana token using only the supplied market data. Be conservative. Do not invent facts.",
        "token": token,
        "output": {
            "risk": "integer 1-10",
            "decision": "WATCH or REJECT",
            "reason": "short explanation",
            "missing_data": ["list"]
        }
    }

    try:
        r = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": "Bearer " + GROQ_KEY},
            json={
                "model": "openai/gpt-oss-120b",
                "messages": [
                    {"role": "system", "content": "Return valid JSON only. You are a cautious crypto risk analyst, not a trading promoter."},
                    {"role": "user", "content": json.dumps(prompt)}
                ],
                "temperature": 0.1,
                "max_tokens": 250
            },
            timeout=45
        )
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        start, end = content.find("{"), content.rfind("}")
        if start < 0 or end < start:
            raise ValueError("JSON yanıtı bulunamadı")
        result = json.loads(content[start:end+1])
        risk = max(1, min(10, int(result.get("risk", 10))))
        return {
            "risk": risk,
            "decision": result.get("decision", "REJECT"),
            "reason": result.get("reason", ""),
            "missing_data": result.get("missing_data", [])
        }
    except Exception as e:
        return {"risk": 10, "decision": "REJECT", "reason": "Groq hatası: " + str(e)}

def analyze(mint):
    try:
        r = requests.get(DEX + mint, timeout=20)
        if r.status_code != 200:
            return None, "DexScreener HTTP " + str(r.status_code)
        pairs = r.json()
        if not isinstance(pairs, list) or not pairs:
            return None, "Henüz DexScreener havuzu yok"

        pairs = [p for p in pairs if p.get("chainId") == "solana"]
        if not pairs:
            return None, "Solana havuzu bulunamadı"

        p = max(pairs, key=lambda x: (x.get("liquidity") or {}).get("usd") or 0)
        liq = float((p.get("liquidity") or {}).get("usd") or 0)
        vol5 = float((p.get("volume") or {}).get("m5") or 0)
        tx = (p.get("txns") or {}).get("m5") or {}
        buys, sells = int(tx.get("buys") or 0), int(tx.get("sells") or 0)
        price_change = float((p.get("priceChange") or {}).get("m5") or 0)
        created = p.get("pairCreatedAt")
        age_min = (time.time()*1000 - created)/60000 if created else None

        data = {
            "mint": mint,
            "name": (p.get("baseToken") or {}).get("name", ""),
            "symbol": (p.get("baseToken") or {}).get("symbol", ""),
            "pair": p.get("pairAddress", ""),
            "url": p.get("url", ""),
            "liquidity_usd": round(liq, 2),
            "volume_5m_usd": round(vol5, 2),
            "buys_5m": buys,
            "sells_5m": sells,
            "transactions_5m": buys+sells,
            "price_change_5m_pct": round(price_change, 2),
            "pair_age_minutes": round(age_min, 1) if age_min is not None else None
        }

        reasons = []
        if liq < MIN_LIQ: reasons.append("Likidite düşük")
        if vol5 < MIN_VOL5: reasons.append("5 dakikalık hacim düşük")
        if buys+sells < MIN_TX5: reasons.append("İşlem sayısı düşük")
        if age_min is None: reasons.append("Havuz yaşı bilinmiyor")

        return data, reasons
    except Exception as e:
        return None, "Veri hatası: " + str(e)

def main():
    source = ROOT / "data" / "pump_new_tokens.jsonl"
    if not source.exists():
        print("Pump token kayıt dosyası bulunamadı.")
        return

    tokens = {}
    for line in source.read_text(encoding="utf-8").splitlines():
        try:
            item = json.loads(line)
            mint = item.get("mint")
            if mint:
                tokens[mint] = item
        except Exception:
            pass

    items = list(tokens.values())[-100:]
    print("Benzersiz token:", len(items))
    print("DexScreener analizi başlıyor...\n")

    results = []
    for i, item in enumerate(items, 1):
        mint = item["mint"]
        data, reasons = analyze(mint)
        name = item.get("name") or item.get("symbol") or mint[:8]

        if data is None:
            print(f"[{i}/{len(items)}] {name}: VERİ YOK - {reasons}")
            time.sleep(0.25)
            continue

        print(
            f"[{i}/{len(items)}] {data['symbol']} | "
            f"Liq ${data['liquidity_usd']:,.0f} | "
            f"Vol5 ${data['volume_5m_usd']:,.0f} | "
            f"İşlem {data['transactions_5m']} | "
            f"5m %{data['price_change_5m_pct']}"
        )

        data["filter_reasons"] = reasons
        if not reasons:
            print("  GROQ RİSK ANALİZİ...")
            data["grok"] = grok_review(data)
            print("  Groq:", data["grok"])
        else:
            data["grok"] = {"risk": 10, "decision": "REJECT", "reason": "; ".join(reasons)}

        results.append(data)
        time.sleep(0.25)

    out = ROOT / "data" / "pump_analysis.json"
    out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")

    passed = [
        x for x in results
        if not x["filter_reasons"]
        and x["grok"].get("decision") == "WATCH"
        and int(x["grok"].get("risk", 10)) <= 4
    ]

    print("\n========== SONUÇ ==========")
    print("Analiz edilen:", len(results))
    print("Temel filtreleri geçen:", sum(not x["filter_reasons"] for x in results))
    print("Groq sonrası WATCH:", len(passed))
    print("Rapor:", out)
    print("NOT: WATCH yalnızca izleme adayıdır; ALIM EMRİ DEĞİLDİR.")

if __name__ == "__main__":
    main()

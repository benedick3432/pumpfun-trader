import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
MODEL = "openai/gpt-oss-120b"


def analyze(token, checks):
    key = os.getenv("GROQ_API_KEY", "").strip()

    if not key:
        return {
            "risk": 10,
            "reasons": ["Groq API key missing"],
            "missing_data": ["API key"]
        }

    prompt = {
        "token": {
            "symbol": token.get("symbol"),
            "address": token.get("address"),
            "liquidity": token.get("liquidity"),
            "volume5m": token.get("volume5m"),
            "price": token.get("price")
        },
        "security_checks": checks
    }

    try:
        response = requests.post(
            GROQ_URL,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json"
            },
            json={
                "model": MODEL,
                "temperature": 0,
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "Analyze Solana token risk. "
                            "Return ONLY valid JSON with risk (0-10), "
                            "reasons (array), missing_data (array). "
                            "10 means extreme risk. "
                            "Never claim a security check passed "
                            "without evidence."
                        )
                    },
                    {
                        "role": "user",
                        "content": json.dumps(prompt)
                    }
                ]
            },
            timeout=45
        )

        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        result = json.loads(content)

        risk = float(result["risk"])

        if not 0 <= risk <= 10:
            raise ValueError("Invalid risk score")

        return {
            "risk": risk,
            "reasons": result.get("reasons", []),
            "missing_data": result.get("missing_data", [])
        }

    except Exception as e:
        return {
            "risk": 10,
            "reasons": [f"Groq error: {e}"],
            "missing_data": ["AI analysis unavailable"]
        }

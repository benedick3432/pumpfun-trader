# Grok Trader Guide

Solana token scanner and paper trading system.

## Run demo
python src/main.py --demo

## Run one scan
python src/main.py --once

## Run continuously
python src/main.py

## Dashboard
python src/dashboard.py

Open http://127.0.0.1:8000

MODE must remain paper.
Live trading is not implemented.
